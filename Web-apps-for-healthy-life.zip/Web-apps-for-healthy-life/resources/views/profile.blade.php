<x-app-layout>
    <div id="profile" class="px-5 max-w-7xl mx-auto sm:px-6 lg:px-8 mt-10"></div>
</x-app-layout>

<script>
    const getProfile = async () => {
        const profile = document.getElementById('profile');
        const response = await fetch(`{{ route('profile') }}`);
        const body = await response.json();
        profile.innerHTML = `
            <form class="flex flex-wrap" methot="POST" onsubmit="updateProfile(event)">
            @csrf
            <div class="w-full md:w-1/2 px-3">
                <label for="name" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">
                    Name
                </label>
                <input id="name" type="text" class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" name="name" value="${body.name}">
            </div>
            <div class="w-full md:w-1/2 px-3">
                <label for="email" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">
                    Email
                </label>
                <input id="email" type="email" class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" name="email" value="${body.email}">
            </div>
            <div class="w-full px-3">
                <label for="old_password" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">
                    Old Password
                </label>
                <input id="old_password" type="password" class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" name="old_password">
            </div>
            <div class="w-full md:w-1/2 px-3">
                <label for="new_password" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">
                    New Password
                </label>
                <input id="new_password" type="password" class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" name="new_password">
            </div>
            <div class="w-full md:w-1/2 px-3">
                <label for="confirm_password" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">
                    Confirm Password
                </label>
                <input id="confirm_password" type="password" class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" name="confirm_password">
            </div>
            <div class="w-full px-3">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    Update
                </button>
            </div>
            </form>
        `;
    }
    getProfile();

    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })

    const updateProfile = async (event) => {
        event.preventDefault();
        const form = event.target;
        const response = await fetch(`{{ route('profile.update') }}`, {
            method: 'POST',
            body: new FormData(form),
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute(
                    'content')
            }
        });
        const result = await response.json();
        if (result.status == 'success') {
            Toast.fire({
                icon: 'success',
                title: `${result.message}`
            });
            getProfile();
        } else {
            Toast.fire({
                icon: 'error',
                title: `${result.message}`
            });
            getProfile();
        }
    }
</script>
