<x-app-layout>
    <div class="py-12 px-5">
        <h1 class="text-center text-4xl">{{ $food->name }}</h1>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex flex-wrap">
            <table class="text-left">
                <tr>
                    <th>Name</th>
                    <td> : {{ $food->name }}</td>
                </tr>
                <tr>
                    <th>Price</th>
                    <td> : {{ $food->price }}</td>
                </tr>
                {{-- calories, carbo, fat --}}
                <tr>
                    <th>Calories</th>
                    <td> : {{ $food->calories }}</td>
                </tr>
                <tr>
                    <th>Carbo</th>
                    <td> : {{ $food->carbo }}</td>
                </tr>
                <tr>
                    <th>Fat</th>
                    <td> : {{ $food->fat }}</td>
                </tr>
                <tr>
                    <th>Category</th>
                    <td> : {{ $food->category->name }}</td>
                </tr>
                <tr>
                    <th>Schedule</th>
                    <td> : {{ $food->schedule->name }}</td>
                </tr>
            </table>
            <h1 class="text-xl">Comments</h1>
        </div>
    </div>
    <div class="px-5 max-w-7xl mx-auto sm:px-6 lg:px-8">
        <h1 class="text-xl font-bold">Comments : </h1>
        @foreach ($comments as $comment)
            <div class="border border-3 p-3 rounded-xl mb-3">
                <h1 class="font-bold">{{ $comment->user->name }}</h1>
                <p>{{ $comment->comment }}</p>
                {{-- reply button --}}
                @foreach ($comment->reply as $reply)
                    <div class="flex justify-end border border-3 mb-1 p-1 rounded-xl">
                        <div>
                            <h1 class="font-bold text-right">{{ $reply->user->name }}</h1>
                            <p class="text-right">{{ $reply->comment }}</p>
                        </div>
                    </div>
                @endforeach
                @auth
                    @if ($ordered)
                        <form action="{{ route('comment.reply', $comment->id) }}" method="POST">
                            @csrf
                            <input type="hidden" name="food_id" value="{{ $food->id }}">
                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3">
                                    <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-password">
                                        Comment
                                    </label>
                                    <textarea
                                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        name="comment" id="comment" rows="3"></textarea>
                                </div>
                            </div>
                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3">
                                    <button type="submit"
                                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                                        Add Comment
                                    </button>
                                </div>
                            </div>
                        </form>
                    @endif
                @endauth
            </div>
        @endforeach
    </div>
    <div class="px-5 max-w-7xl mx-auto sm:px-6 lg:px-8">
        @auth
            @if ($ordered)
                <h1 class="text-xl font-bold">Add Comment : </h1>
                <form action="{{ route('comment.store') }}" method="POST">
                    @csrf
                    <input type="hidden" name="food_id" value="{{ $food->id }}">
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="grid-password">
                                Comment
                            </label>
                            <textarea
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                name="comment" id="comment" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full px-3">
                            <button type="submit"
                                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                                Add Comment
                            </button>
                        </div>
                    </div>
                </form>
            @else
                <h1 class="text-xl font-bold">You have to order this food first</h1>
            @endif
        @endauth
</x-app-layout>
