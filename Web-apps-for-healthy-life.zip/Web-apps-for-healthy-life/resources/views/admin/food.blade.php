<x-app-layout>
    <div class="py-12 px-5">
        <h1 class="text-center text-4xl">Food</h1>
        <div class="flex justify-end">
            <button class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded mb-3" data-bs-toggle="modal"
                data-bs-target="#addModal">
                <i class="bi bi-plus"></i>
            </button>
        </div>
        <div class="flex flex-col">
            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                <div class="py-2 align-middle inline-block w-full sm:px-6 lg:px-8">
                    <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                        <table class="w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Name
                                    </th>
                                    <th colspan="2"
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200" id="data-food">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

<!-- Add Modal -->
<div class="modal hidden fixed top-0 left-0 w-full h-full outline-none fade" id="addModal" tabindex="-1" role="dialog">
    <div class="modal-dialog relative w-auto pointer-events-none max-w-lg my-8 mx-auto px-4 sm:px-0" role="document">
        <div class="relative flex flex-col w-full pointer-events-auto bg-white border border-gray-300 rounded-lg">
            <div class="flex items-start justify-between p-4 border-b border-gray-300 rounded-t">
                <h5 class="mb-0 text-lg leading-normal" id="modal-title">New food</h5>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <form onsubmit="addFood(event)" method="post" class="w-full">
                <div class="relative flex flex-wrap p-4 w-full gap-1">
                    @csrf
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="add-name">
                                Name
                            </label>
                            <input name="name"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="add-name" type="text" placeholder="Name">
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="add-calories">
                                Calories
                            </label>
                            <input name="calories"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="add-calories" type="text" placeholder="Calories">
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="add-carbo">
                                Carbo
                            </label>
                            <input name="carbo"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="add-carbo" type="text" placeholder="Carbo">
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="add-fat">
                                Fat
                            </label>
                            <input name="fat"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="add-fat" type="text" placeholder="Fat">
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="add-categories_id">
                                Categories
                            </label>
                            <select name="category_id"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="add-categories_id">
                            </select>
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="add-schedule_id">
                                Schedule
                            </label>
                            <select name="schedule_id"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="add-schedule_id">
                            </select>
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="add-price">
                                Price
                            </label>
                            <input name="price"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="add-price" type="number" placeholder="Price">
                        </div>
                    </div>

                </div>
                <div class="flex items-center justify-end p-4">
                    <button type="submit"
                        class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-blue-600 mr-2">Add</button>
                    <button type="button"
                        class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-gray-600 mr-2"
                        data-bs-dismiss="modal" id="closeModal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- End Add Modal -->

<!-- Edit Modal -->
<div class="modal hidden fixed top-0 left-0 w-full h-full outline-none fade" id="editModal" tabindex="-1" role="dialog">
    <div class="modal-dialog relative w-auto pointer-events-none max-w-lg my-8 mx-auto px-4 sm:px-0" role="document">
        <div class="relative flex flex-col w-full pointer-events-auto bg-white border border-gray-300 rounded-lg">
            <div class="flex items-start justify-between p-4 border-b border-gray-300 rounded-t">
                <h5 class="mb-0 text-lg leading-normal" id="modal-title">Edit Food</h5>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <div id="edit-body"></div>
        </div>
    </div>
</div>
<!-- End Edit Modal -->

<script>
    document.addEventListener('DOMContentLoaded', async () => {
        await getFood();
    });

    const getFood = async () => {
        const response = await fetch(`{{ route('food.get') }}`);
        const data = await response.json();
        const dataFood = document.getElementById('data-food');
        const addCategoriesId = document.getElementById('add-categories_id');
        const addScheduleId = document.getElementById('add-schedule_id');
        addCategoriesId.innerHTML = '<option selected disabled>Category</option>';
        addScheduleId.innerHTML = '<option selected disabled>Schedule</option>';
        let dataCategory = '';
        let dataSchedule = '';
        data.categories.forEach(category => {
            dataCategory += `<option value="${category.id}">${category.name}</option>`;
        });
        data.schedules.forEach(schedule => {
            dataSchedule += `<option value="${schedule.id}">${schedule.name}</option>`;
        });
        addCategoriesId.innerHTML += dataCategory;
        addScheduleId.innerHTML += dataSchedule;
        const dataCategories = data.categories;
        const dataSchedules = data.schedules;

        let html = '';
        data.foods.forEach(food => {
            console.log(food);
            html += `
                <tr>
                    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
                        ${food.name}
                    </td>
                    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-500">
                        <button class="text-indigo-600 hover:text-indigo-900"
                        data-bs-toggle="modal" data-bs-target="#editModal" data-bs-id="${food.id}">
                            <i class="bi bi-pencil"></i>
                        </button>
                    </td>
                    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-500">
                        <button onclick="deleteFood(${food.id})" class="text-red-600 hover:text-red-900" onclick="deleteFood(${food.id})">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
        dataFood.innerHTML = html;
        const editModal = document.getElementById('editModal');
        const buttons = document.querySelectorAll('[data-bs-toggle="modal"][data-bs-target="#editModal"]');
        const closeButtons = document.querySelectorAll('[data-bs-dismiss="modal"]');
        buttons.forEach(button => {
            button.addEventListener('click', async () => {
                const id = button.getAttribute('data-bs-id');
                const response = await fetch(`{{ route('food.detail.get', ':id') }}`
                    .replace(':id', id));
                const data = await response.json();
                const editBody = document.getElementById('edit-body');
                editBody.innerHTML = `
                <form onsubmit="updateFood(event, ${id})" method="post" class="w-full">
                <div class="relative flex flex-wrap p-4 w-full gap-1">
                    @csrf
                    @method('PUT')
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="edit-name">
                                Name
                            </label>
                            <input name="name"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="edit-name" type="text" placeholder="Name" value="${data.name}">
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="edit-calories">
                                Calories
                            </label>
                            <input name="calories"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="edit-calories" type="text" placeholder="Calories" value="${data.calories}">
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="edit-carbo">
                                Carbo
                            </label>
                            <input name="carbo"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="edit-carbo" type="text" placeholder="Carbo" value="${data.carbo}">
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="edit-fat">
                                Fat
                            </label>
                            <input name="fat"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="edit-fat" type="text" placeholder="Fat" value="${data.fat}">
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="edit-categories_id">
                                Categories
                            </label>
                            <select name="category_id"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="edit-categories_id">
                                <option selected disabled>Category</option>
                                ${dataCategories.map(category => `
                                    <option value="${category.id}" ${category.id == data.category_id ? 'selected' : ''}>
                                        ${category.name}
                                    </option>
                                `).join('')}
                            </select>
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="edit-schedule_id">
                                Schedule
                            </label>
                            <select name="schedule_id"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="edit-schedule_id">
                                <option selected disabled>Schedule</option>
                                ${dataSchedules.map(schedule => `
                                    <option value="${schedule.id}" ${schedule.id == data.schedule_id ? 'selected' : ''}>
                                        ${schedule.name}
                                    </option>
                                `).join('')}
                            </select>
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6 w-1/2">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="edit-price">
                                Price
                            </label>
                            <input name="price"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="edit-price" type="number" placeholder="Price" value="${data.price}">
                        </div>
                    </div>

                </div>
                <div class="flex items-center justify-end p-4">
                    <button type="submit"
                        class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-blue-600 mr-2">Save</button>
                    <button type="button"
                        class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-gray-600 mr-2"
                        data-bs-dismiss="modal" id="closeModal">Close</button>
                </div>
            </form>
                `;
            });
        });

    }

    const addFood = async (event) => {
        event.preventDefault();
        const form = event.target;
        const data = new FormData(form);
        const response = await fetch(`{{ route('food.store') }}`, {
            method: 'POST',
            body: data
        });
        await getFood();
        form.reset();
        document.getElementById('closeModal').click();
    }

    const updateFood = async (event, id) => {
        event.preventDefault();
        const form = event.target;
        const data = new FormData(form);
        const response = await fetch(`{{ route('food.update', ':id') }}`.replace(':id', id), {
            method: 'POST',
            body: data
        });
        await getFood();
        form.reset();
        document.getElementById('editModal').click();
    }

    const deleteFood = async (id) => {
        const response = await fetch(`{{ route('food.delete', ':id') }}`.replace(':id', id), {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        });
        await getFood();
    }
</script>
