<x-app-layout>
    <div class="py-12 px-5">
        <h1 class="text-center text-4xl">All User</h1>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex flex-wrap">
            @foreach ($users as $user)
                <div class="w-full sm:w-1/2 lg:w-1/3 p-3">
                    <div class="bg-white rounded-lg shadow-lg">
                        <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2">{{ $user->name }}</div>
                            <div class="text-gray-700 text-base">
                                {{ $user->email }}
                            </div>
                        </div>
                        <div class="px-6 py-4">
                            <a href="{{ route('chat.user', $user->id) }}"><i class="bi bi-send"></i></a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</x-app-layout>
