<x-app-layout>
    <div class="py-12">
        <h1 class="text-center text-4xl">Transaction history</h1>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex flex-wrap">
            @foreach ($transactions as $transaction)
                <div
                    class="border border-blue-300 hover:bg-blue-500 hover:text-white shadow rounded-md p-4 max-w-sm w-full mx-auto mb-3">
                    <div class="flex space-x-4">
                        <div class="flex-1">
                            {{ $transaction->created_at->format('d/m/Y') }}
                            {{ $transaction->created_at->diffForHumans() }}
                            <div class="space-y-3">
                                <div class="grid grid-cols-3 gap-4">
                                    Rp.{{ number_format($transaction->price) }}
                                </div>
                            </div>
                        </div>
                        <div class="flex-2 justify-end">
                            <button
                                class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-blue-600 mr-2"
                                data-bs-toggle="modal" data-bs-target="#detailModal"
                                data-bs-id="{{ $transaction->id }}">Detail</button>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</x-app-layout>

<!-- detail Modal -->
<div class="modal hidden fixed top-0 left-0 w-full h-full outline-none fade" id="detailModal" tabindex="-1"
    role="dialog">
    <div class="modal-dialog relative w-auto pointer-events-none max-w-lg my-8 mx-auto px-4 sm:px-0" role="document">
        <div class="relative flex flex-col w-full pointer-events-auto bg-white border border-gray-300 rounded-lg">
            <div class="flex items-start justify-between p-4 border-b border-gray-300 rounded-t">
                <h5 class="mb-0 text-lg leading-normal">Detail</h5>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <div class="relative flex flex-wrap p-4" id="detail-body"></div>
            <div class="flex items-center justify-end p-4">
                <button type="button"
                    class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-gray-600 mr-2"
                    data-bs-dismiss="modal" id="closeModal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- End detail Modal -->

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const detailBody = document.getElementById('detail-body');

        const buttons = document.querySelectorAll('[data-bs-toggle="modal"][data-bs-target="#detailModal"]');
        buttons.forEach(button => {
            button.addEventListener('click', e => {
                detailBody.innerHTML = `
                <div class="border border-blue-300 shadow rounded-md p-4 max-w-sm w-full mx-auto">
									<div class="animate-pulse flex space-x-4">
										<div class="rounded-full bg-gray-200 h-10 w-10"></div>
										<div class="flex-1 space-y-6 py-1">
											<div class="h-2 bg-gray-200 rounded"></div>
											<div class="space-y-3">
												<div class="grid grid-cols-3 gap-4">
													<div class="h-2 bg-gray-200 rounded col-span-2"></div>
													<div class="h-2 bg-gray-200 rounded col-span-1"></div>
												</div>
												<div class="h-2 bg-gray-200 rounded"></div>
											</div>
										</div>
									</div>
								</div>`;
                const id = e.target.dataset.bsId;
                const url = `{{ route('transaction.detail', ':id') }}`.replace(':id', id);
                let html = '';
                fetch(url)
                    .then(res => res.json())
                    .then(res => {
                        res.forEach(item => {
                            console.log(item);
                            html += `
                                <div class="flex space-x-4 w-full">
                                    <div class="flex-1">
                                        ${item.food.name}
                                    </div>
                                    <div class="flex-2 justify-end">
                                        Rp.${item.food.price}
                                    </div>
                                </div>
                            `;
                        });
                    })
                    .then(() => {
                        detailBody.innerHTML = html;
                    });
            });
        });
    })
</script>
