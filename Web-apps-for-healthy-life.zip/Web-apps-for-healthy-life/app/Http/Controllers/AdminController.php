<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Food;
use App\Models\Schedule;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function category()
    {
        return view('admin.category');
    }

    public function getCategory()
    {
        $categories = Category::all();
        return response()->json($categories);
    }

    public function addCategory(Request $request)
    {
        Category::create([
            'name' => $request->name,
        ]);
        return response()->json(['success' => true]);
    }

    public function getCategoryById(Category $category)
    {
        return response()->json($category);
    }

    public function updateCategory(Request $request, Category $category)
    {
        $category->update([
            'name' => $request->name,
        ]);
        return response()->json(['success' => true]);
    }

    public function deleteCategory(Category $category)
    {
        $category->delete();
        return response()->json(['success' => true]);
    }

    public function food()
    {
        return view('admin.food');
    }

    public function getFood()
    {
        $foods = Food::with('category')->get();
        $categories = Category::all();
        $schedules = Schedule::all();
        return response()->json([
            'foods' => $foods,
            'categories' => $categories,
            'schedules' => $schedules,
        ]);
    }

    public function addFood(Request $request)
    {
        Food::create([
            'name' => $request->name,
            'price' => $request->price,
            'calories' => $request->calories,
            'carbo' => $request->carbo,
            'fat' => $request->fat,
            'category_id' => $request->category_id,
            'schedule_id' => $request->schedule_id,
            'price' => $request->price,
        ]);
        return response()->json(['success' => true]);
    }

    public function getFoodById(Food $food)
    {
        return response()->json($food);
    }

    public function updateFood(Request $request, Food $food)
    {
        $food->update([
            'name' => $request->name,
            'price' => $request->price,
            'calories' => $request->calories,
            'carbo' => $request->carbo,
            'category_id' => $request->category_id,
            'schedule_id' => $request->schedule_id,
            'price' => $request->price,
        ]);
        return response()->json(['success' => true]);
    }

    public function deleteFood(Food $food)
    {
        $food->delete();
        return response()->json(['success' => true]);
    }

    public function getSchedule()
    {
        $schedules = Schedule::all();
        return response()->json($schedules);
    }
}
