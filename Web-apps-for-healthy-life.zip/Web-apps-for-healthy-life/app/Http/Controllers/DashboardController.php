<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Chat;
use App\Models\Comment;
use App\Models\Food;
use App\Models\Transaction;
use App\Models\TransactionDetail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class DashboardController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::all();
        $foods = Food::with('schedule')->get();
        return view('dashboard', compact('categories', 'foods'));
    }

    public function addFood(Request $request)
    {
        $ada = Transaction::where('user_id', Auth::user()->id)->where('status', 0)->count();
        if ($ada > 0) {
            $transaction = Transaction::where('user_id', Auth::user()->id)->where('status', 0)->first();
            $sudah = TransactionDetail::where('transaction_id', $transaction->id)->where('food_id', $request->food_id)->count();
            if ($sudah > 0) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Makanan ini sudah ada di keranjang'
                ]);
            } else {
                TransactionDetail::create([
                    'transaction_id' => $transaction->id,
                    'food_id' => $request->food_id,
                ]);
                return response()->json([
                    'status' => 'success',
                    'message' => 'Makanan berhasil ditambahkan'
                ]);
            }
        } else {
            Transaction::create([
                'user_id' => Auth::user()->id,
                'status' => 0,
            ]);
            $transaction = Transaction::where('user_id', Auth::user()->id)->where('status', 0)->first();
            TransactionDetail::create([
                'transaction_id' => $transaction->id,
                'food_id' => $request->food_id,
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Makanan berhasil ditambahkan'
            ]);
        }
    }

    public function getCart()
    {
        $ada = Transaction::where('user_id', Auth::user()->id)->where('status', 0)->count();
        if ($ada > 0) {
            $transaction = Transaction::where('user_id', Auth::user()->id)->where('status', 0)->first();
            $carts = TransactionDetail::with('food')->where('transaction_id', $transaction->id)->get();
            return response()->json($carts);
        } else {
            return response()->json([]);
        }
    }

    public function foodDetail(Food $food)
    {
        $food = Food::with('schedule', 'category')->where('id', $food->id)->first();
        $comments = Comment::with('user', 'reply')->where('food_id', $food->id)->where('reply_id', 0)->get();
        $transaction = Transaction::with('transactionDetails')->where('user_id', Auth::user()->id)->where('status', 1)->get();
        $ordered = false;
        foreach ($transaction as $tr) {
            foreach ($tr->transactionDetails as $td) {
                if ($td->food_id == $food->id) {
                    $ordered = true;
                }
            }
        }
        return view('food-detail', compact('food', 'comments', 'ordered'));
    }

    public function addComment(Request $request)
    {
        Comment::create([
            'user_id' => Auth::user()->id,
            'food_id' => $request->food_id,
            'comment' => $request->comment,
        ]);
        return redirect()->back();
    }

    public function addReply(Request $request, Comment $comment)
    {
        Comment::create([
            'user_id' => Auth::user()->id,
            'food_id' => $request->food_id,
            'comment' => $request->comment,
            'reply_id' => $comment->id,
        ]);
        return redirect()->back();
    }

    public function deleteCart(TransactionDetail $transactionDetail)
    {
        $transactionDetail->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Makanan berhasil dihapus'
        ]);
    }

    public function checkout(Request $request)
    {
        Transaction::where('user_id', Auth::user()->id)->where('status', 0)->update([
            'status' => 1,
            'price' => $request->price,
        ]);
        return response()->json([
            'status' => 'success',
            'message' => 'Pesanan berhasil dibayar'
        ]);
    }

    public function getTransaction()
    {
        $transactions = Transaction::with('user')->where('user_id', Auth::user()->id)->where('status', 1)->latest()->get();
        return view('transaction', compact('transactions'));
    }

    public function getTransactionDetail(Transaction $transaction)
    {
        $transaction = Transaction::with('user')->where('id', $transaction->id)->first();
        $transactionDetails = TransactionDetail::with('food')->where('transaction_id', $transaction->id)->get();
        return response()->json($transactionDetails);
    }

    public function getChat()
    {
        $chats = Chat::with('user')->where('user_id', Auth::user()->id)->orWhere('reply_id', Auth::user()->id)->get();
        return response()->json($chats);
    }

    public function sendChat(Request $request)
    {
        Chat::create([
            'user_id' => Auth::user()->id,
            'reply_id' => 0,
            'message' => $request->message,
        ]);
        return response()->json([
            'status' => 'success',
        ]);
    }

    public function getAllUser()
    {
        $users = User::where('id', '!=', Auth::user()->id)->get();
        return view('admin.all-user', compact('users'));
    }

    public function getChatUser(User $user)
    {
        return view('admin.chat', compact('user'));
    }

    public function getChatUserById(User $user)
    {
        $chats = Chat::with('user')->where('user_id', $user->id)->orWhere('reply_id', $user->id)->get();
        return response()->json($chats);
    }

    public function sendChatUser(Request $request, User $user)
    {
        Chat::create([
            'user_id' => 0,
            'reply_id' => $user->id,
            'message' => $request->message,
        ]);
        return response()->json([
            'status' => 'success',
        ]);
    }

    public function getProfile()
    {
        $user = User::where('id', Auth::user()->id)->first();
        return response()->json($user);
    }

    public function updateProfile(Request $request)
    {
        $user = User::find(Auth::user()->id);
        $user->name = $request->name;
        $user->email = $request->email;
        if ($request->new_password != null) {
            if (Hash::check($request->old_password, $user->password)) {
                if ($request->new_password == $request->confirm_password) {
                    $user->password = Hash::make($request->new_password);
                } else {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Password baru tidak sama'
                    ]);
                }
            } else {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Password lama tidak sama'
                ]);
            }
        }else{
            $user->password = $user->password;
        }
        $user->save();
        return response()->json([
            'status' => 'success',
            'message' => 'Profil berhasil diubah'
        ]);
    }
}
