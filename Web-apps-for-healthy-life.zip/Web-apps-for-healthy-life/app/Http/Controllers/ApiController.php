<?php

namespace App\Http\Controllers;

use App\Models\Food;
use App\Models\Transaction;
use App\Models\TransactionDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ApiController extends Controller
{
    public function getFoodByCategory(Request $request)
    {
        $foods = Food::with('schedule')->where('category_id', $request->id)->get();
        return response()->json($foods);
    }
}
