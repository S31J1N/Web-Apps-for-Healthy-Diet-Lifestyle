<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="h-screen pb-24 bg-gray-100 p-8 overflow-scroll" id="chat">
        <div class="max-w-4xl mx-auto space-y-1 grid grid-cols-1" id="chat-body">
        </div>
    </div>
    <form action="<?php echo e(route('chat.send')); ?>" method="post" onsubmit="sendChat(event)">
        <?php echo csrf_field(); ?>
        <div class="place-self-start fixed bottom-0 left-0 w-full">
            <div class="bg-white flex">
                <textarea class="flex-auto border-0" name="message" id="message"
                    placeholder="Type your message here..."></textarea>
                <button class="flex-none w-14 bg-blue-500 hover:bg-blue-600 text-white"><i
                        class="bi bi-send"></i></button>
            </div>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script>
    const goToBottom = () => {
        const chat = document.getElementById('chat');
        chat.scrollTop = chat.scrollHeight - chat.clientHeight;
    }
    goToBottom();

    const sendChat = async (event) => {
        event.preventDefault();
        const form = event.target;
        const url = form.action;
        const data = new FormData(form);
        const response = await fetch(url, {
            method: 'POST',
            body: data
        });
        document.getElementById('message').value = '';
        getChat();
    }

    const nl2br = (str, is_xhtml) => {
        if (typeof str === 'undefined' || str === null) {
            return '';
        }
        var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
        return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
    }

    const getChat = async () => {
        const response = await fetch(`<?php echo e(route('chat.get')); ?>`);
        const data = await response.json();
        const chat = document.getElementById('chat-body');
        let html = ''
        data.forEach(message => {
            if (message.user_id == <?php echo e(Auth::user()->id); ?>) {
                html += `
                    <div class="place-self-end text-right">
                        <div class="bg-green-50 text-green-900 px-2 py-1 rounded-2xl rounded-tr-none">
                            ${nl2br(message.message)}
                        </div>
                    </div>
                `
            } else {
                html += `
                    <div class="place-self-start text-left">
                        <div class="bg-white px-2 py-1 rounded-2xl rounded-tl-none">
                            ${nl2br(message.message)}
                        </div>
                    </div>
                `
            }
        });
        chat.innerHTML = html;

        goToBottom();
    }

    setInterval(getChat, 1000);
</script>
<?php /**PATH /home/ubuntu/Downloads/mobile-apps-for-healthy-life/mobile-apps-for-healthy-life/resources/views/chat.blade.php ENDPATH**/ ?>