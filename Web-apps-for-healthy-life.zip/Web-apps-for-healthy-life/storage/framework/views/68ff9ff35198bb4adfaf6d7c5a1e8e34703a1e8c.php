<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 px-5">
        <h1 class="text-center text-4xl">All User</h1>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex flex-wrap">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-full sm:w-1/2 lg:w-1/3 p-3">
                    <div class="bg-white rounded-lg shadow-lg">
                        <div class="px-6 py-4">
                            <div class="font-bold text-xl mb-2"><?php echo e($user->name); ?></div>
                            <div class="text-gray-700 text-base">
                                <?php echo e($user->email); ?>

                            </div>
                        </div>
                        <div class="px-6 py-4">
                            <a href="<?php echo e(route('chat.user', $user->id)); ?>"><i class="bi bi-send"></i></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH E:\COLLEGE\Semester 5\OOAD\Project-Dosen\mobile-apps-for-healthy-life\resources\views/admin/all-user.blade.php ENDPATH**/ ?>