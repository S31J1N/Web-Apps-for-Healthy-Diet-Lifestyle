<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 px-5">
        <h1 class="text-center text-4xl">Category</h1>
        <div class="flex justify-end">
            <button class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded mb-3" data-bs-toggle="modal"
                data-bs-target="#addModal">
                <i class="bi bi-plus"></i>
            </button>
        </div>
        <div class="flex flex-col">
            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                <div class="py-2 align-middle inline-block w-full sm:px-6 lg:px-8">
                    <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                        <table class="w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Name
                                    </th>
                                    <th colspan="2"
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200" id="data-category">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<!-- Add Modal -->
<div class="modal hidden fixed top-0 left-0 w-full h-full outline-none fade" id="addModal" tabindex="-1" role="dialog">
    <div class="modal-dialog relative w-auto pointer-events-none max-w-lg my-8 mx-auto px-4 sm:px-0" role="document">
        <div class="relative flex flex-col w-full pointer-events-auto bg-white border border-gray-300 rounded-lg">
            <div class="flex items-start justify-between p-4 border-b border-gray-300 rounded-t">
                <h5 class="mb-0 text-lg leading-normal" id="modal-title">New Category</h5>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <form onsubmit="addCategory(event)" action="<?php echo e(route('category.store')); ?>" method="post"
                class="w-full">
                <div class="relative flex flex-wrap p-4 w-full">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-wrap -mx-3 mb-6 w-full">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="add-name">
                                Name
                            </label>
                            <input name="name"
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                id="add-name" type="text" placeholder="Name">
                        </div>
                    </div>
                </div>
                <div class="flex items-center justify-end p-4">
                    <button type="submit"
                        class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-blue-600 mr-2">Add</button>
                    <button type="button"
                        class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-gray-600 mr-2"
                        data-bs-dismiss="modal" id="closeModal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- End Add Modal -->

<!-- Edit Modal -->
<div class="modal hidden fixed top-0 left-0 w-full h-full outline-none fade" id="editModal" tabindex="-1" role="dialog">
    <div class="modal-dialog relative w-auto pointer-events-none max-w-lg my-8 mx-auto px-4 sm:px-0" role="document">
        <div class="relative flex flex-col w-full pointer-events-auto bg-white border border-gray-300 rounded-lg">
            <div class="flex items-start justify-between p-4 border-b border-gray-300 rounded-t">
                <h5 class="mb-0 text-lg leading-normal" id="modal-title">Edit Category</h5>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <div class="relative flex flex-wrap p-4 w-full" id="edit-body"></div>
        </div>
    </div>
</div>
<!-- End Edit Modal -->

<script>
    document.addEventListener('DOMContentLoaded', async () => {
        await getCategory();
    });

    const editCategory = async (event, id) => {
        event.preventDefault();
        const form = event.target;
        const data = new FormData(form);
        const url = `<?php echo e(route('category.update', ':id')); ?>`.replace(':id', id);
        console.log(url);
        const response = await fetch(url, {
            method: 'POST',
            body: data,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute(
                    'content')
            }
        });
        document.getElementById('editModal').click();
        await getCategory();
    }
    const getCategory = async () => {
        const response = await fetch(`<?php echo e(route('category.get')); ?>`);
        const data = await response.json();
        let html = '';
        data.forEach(element => {
            html += `
                            <tr>
                                <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
                                    ${element.name}
                                </td>
                                <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-500">
                                        <button class="text-indigo-600 hover:text-indigo-900"
                                            data-bs-toggle="modal" data-bs-target="#editModal" data-bs-id="${element.id}">
                                            <i class="bi bi-pen"></i>
                                        </button>
                                </td>
                                <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 text-gray-500">
                                    <button onclick="deleteCategory(${element.id})" class="text-red-600 hover:text-red-900"
                                            data-bs-toggle="modal" data-bs-target="#cartModal">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                </td>
                            </tr>
                        `;
        });
        document.getElementById('data-category').innerHTML = html;
        const editModal = document.getElementById('editModal');
        const buttons = document.querySelectorAll('[data-bs-toggle="modal"][data-bs-target="#editModal"]');
        const closeButtons = document.querySelectorAll('[data-bs-dismiss="modal"]');
        buttons.forEach(button => {
            button.addEventListener('click', async () => {
                const id = button.getAttribute('data-bs-id');
                const url = `<?php echo e(route('category.detail', ':id')); ?>`.replace(':id',
                    id);
                const editBody = document.getElementById('edit-body');
                editBody.innerHTML = 'loading...';
                const html = '';
                const response = await fetch(url);
                const data = await response.json();
                editBody.innerHTML = `
                    <form onsubmit="editCategory(event, ${id})" method="POST" class="w-full">
                        <div class="relative flex flex-wrap p-4 w-full">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="id" value="${id}">
                            <div class="flex flex-wrap -mx-3 mb-6 w-full">
                                <div class="w-full px-3">
                                    <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="edit-name">
                                        Name
                                    </label>
                                    <input name="name"
                                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        type="text" placeholder="Name" value="${data.name}">
                                </div>
                            </div>
                        </div>
                        <div class="flex items-center justify-end p-4">
                            <button type="submit"
                                class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-blue-600 mr-2">Save</button>
                            <button type="button" class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-gray-600 mr-2"
                                data-bs-dismiss="modal">Close</button>
                        </div>
                    </form>
                `;
            });
        });
    }


    const addCategory = async (e) => {
        e.preventDefault();
        const form = e.target;
        const data = new FormData(form);
        const response = await fetch(`<?php echo e(route('category.store')); ?>`, {
            method: 'POST',
            body: data
        });
        document.getElementById('closeModal').click();
        document.getElementById('add-name').value = '';
        await getCategory();
    }

    const deleteCategory = async (id) => {
        const response = await fetch(`<?php echo e(route('category.delete', ':id')); ?>`.replace(':id', id), {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute(
                    'content')
            }
        });
        document.getElementById('closeModal').click();
        await getCategory();
    }
</script>
<?php /**PATH E:\COLLEGE\Semester 5\OOAD\Project-Dosen\mobile-apps-for-healthy-life\resources\views/admin/category.blade.php ENDPATH**/ ?>