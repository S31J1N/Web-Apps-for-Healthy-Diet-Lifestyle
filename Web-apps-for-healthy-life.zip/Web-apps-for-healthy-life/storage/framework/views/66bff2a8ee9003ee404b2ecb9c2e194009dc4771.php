<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 px-5">
        <h1 class="text-center text-4xl"><?php echo e($food->name); ?></h1>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex flex-wrap">
            <table class="text-left">
                <tr>
                    <th>Name</th>
                    <td> : <?php echo e($food->name); ?></td>
                </tr>
                <tr>
                    <th>Price</th>
                    <td> : <?php echo e($food->price); ?></td>
                </tr>
                
                <tr>
                    <th>Calories</th>
                    <td> : <?php echo e($food->calories); ?></td>
                </tr>
                <tr>
                    <th>Carbo</th>
                    <td> : <?php echo e($food->carbo); ?></td>
                </tr>
                <tr>
                    <th>Fat</th>
                    <td> : <?php echo e($food->fat); ?></td>
                </tr>
                <tr>
                    <th>Category</th>
                    <td> : <?php echo e($food->category->name); ?></td>
                </tr>
                <tr>
                    <th>Schedule</th>
                    <td> : <?php echo e($food->schedule->name); ?></td>
                </tr>
            </table>
            <h1 class="text-xl">Comments</h1>
        </div>
    </div>
    <div class="px-5 max-w-7xl mx-auto sm:px-6 lg:px-8">
        <h1 class="text-xl font-bold">Comments : </h1>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border border-3 p-3 rounded-xl mb-3">
                <h1 class="font-bold"><?php echo e($comment->user->name); ?></h1>
                <p><?php echo e($comment->comment); ?></p>
                
                <?php $__currentLoopData = $comment->reply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex justify-end border border-3 mb-1 p-1 rounded-xl">
                        <div>
                            <h1 class="font-bold text-right"><?php echo e($reply->user->name); ?></h1>
                            <p class="text-right"><?php echo e($reply->comment); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(auth()->guard()->check()): ?>
                    <?php if($ordered): ?>
                        <form action="<?php echo e(route('comment.reply', $comment->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="food_id" value="<?php echo e($food->id); ?>">
                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3">
                                    <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                        for="grid-password">
                                        Comment
                                    </label>
                                    <textarea
                                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        name="comment" id="comment" rows="3"></textarea>
                                </div>
                            </div>
                            <div class="flex flex-wrap -mx-3 mb-6">
                                <div class="w-full px-3">
                                    <button type="submit"
                                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                                        Add Comment
                                    </button>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="px-5 max-w-7xl mx-auto sm:px-6 lg:px-8">
        <?php if(auth()->guard()->check()): ?>
            <?php if($ordered): ?>
                <h1 class="text-xl font-bold">Add Comment : </h1>
                <form action="<?php echo e(route('comment.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="food_id" value="<?php echo e($food->id); ?>">
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full px-3">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                                for="grid-password">
                                Comment
                            </label>
                            <textarea
                                class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                name="comment" id="comment" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full px-3">
                            <button type="submit"
                                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                                Add Comment
                            </button>
                        </div>
                    </div>
                </form>
            <?php else: ?>
                <h1 class="text-xl font-bold">You have to order this food first</h1>
            <?php endif; ?>
        <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/ubuntu/Downloads/mobile-apps-for-healthy-life/mobile-apps-for-healthy-life/resources/views/food-detail.blade.php ENDPATH**/ ?>