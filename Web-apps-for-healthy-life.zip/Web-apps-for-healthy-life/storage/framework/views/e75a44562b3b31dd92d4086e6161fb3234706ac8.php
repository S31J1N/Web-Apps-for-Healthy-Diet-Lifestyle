<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <h1 class="text-center text-4xl">Choose Your Diet Meal </h1>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex flex-wrap">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="w-full md:w-1/3 p-3 text-left" data-bs-toggle="modal" data-bs-target="#categoryModal"
                    data-bs-id="<?php echo e($category->id); ?>" data-bs-title="<?php echo e($category->name); ?>">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div
                            class="p-6 bg-yellow-300 hover:bg-purple-500 text-gray-700 hover:text-white border-b border-gray-200">
                            <div class="-my-2 py-2 px-2 flex flex-col sm:flex-row">
                                <div class="w-full sm:w-1/2">
                                    <label for="name" class="block text-sm font-medium leading-5">
                                        <?php echo e($category->name); ?>

                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role == 'user'): ?>
                <div class="flex justify-center gap-1">
                    <button id="cart-modal" class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded"
                        data-bs-toggle="modal" data-bs-target="#cartModal">
                        <i class="bi bi-cart"></i> Cart
                    </button>
                    <a href="<?php echo e(route('transaction.get')); ?>"
                        class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded">
                        <i class="bi bi-wallet"></i> Transaction History</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<!-- Category Modal -->
<div class="modal hidden fixed top-0 left-0 w-full h-full outline-none fade" id="categoryModal" tabindex="-1"
    role="dialog">
    <div class="modal-dialog relative w-auto pointer-events-none max-w-lg my-8 mx-auto px-4 sm:px-0" role="document">
        <div class="relative flex flex-col w-full pointer-events-auto bg-white border border-gray-300 rounded-lg">
            <div class="flex items-start justify-between p-4 border-b border-gray-300 rounded-t">
                <h5 class="mb-0 text-lg leading-normal" id="modal-title"></h5>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <div class="relative flex flex-wrap p-4" id="modal-body"></div>
            <div class="flex items-center justify-end p-4">
                <button type="button"
                    class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-gray-600 mr-2"
                    data-bs-dismiss="modal" id="closeModal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- End Category Modal -->

<!-- cart Modal -->
<div class="modal hidden fixed top-0 left-0 w-full h-full outline-none fade" id="cartModal" tabindex="-1" role="dialog">
    <div class="modal-dialog relative w-auto pointer-events-none max-w-lg my-8 mx-auto px-4 sm:px-0" role="document">
        <div class="relative flex flex-col w-full pointer-events-auto bg-white border border-gray-300 rounded-lg">
            <div class="flex items-start justify-between p-4 border-b border-gray-300 rounded-t">
                <h5 class="mb-0 text-lg leading-normal">Carts</h5>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <div class="relative flex flex-wrap p-4" id="cart-body"></div>
            <div class="flex items-center justify-end p-4">
                <button type="button"
                    class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-gray-600 mr-2"
                    data-bs-dismiss="modal" id="closeModal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- End cart Modal -->

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const modal = document.querySelector('#categoryModal');
        const buttons = document.querySelectorAll('[data-bs-toggle="modal"]');
        const closeButtons = document.querySelectorAll('[data-bs-dismiss="modal"]');

        buttons.forEach(button => {
            button.addEventListener('click', () => {
                const id = button.getAttribute('data-bs-id');
                const title = button.getAttribute('data-bs-title');
                document.querySelector('#modal-title').innerHTML = title;
                const url = `<?php echo e(route('food.category', ':id')); ?>`.replace(':id', id);
                const modalBody = document.querySelector('#modal-body');
                modalBody.innerHTML = `
                <div class="border border-blue-300 shadow rounded-md p-4 max-w-sm w-full mx-auto">
									<div class="animate-pulse flex space-x-4">
										<div class="rounded-full bg-gray-200 h-10 w-10"></div>
										<div class="flex-1 space-y-6 py-1">
											<div class="h-2 bg-gray-200 rounded"></div>
											<div class="space-y-3">
												<div class="grid grid-cols-3 gap-4">
													<div class="h-2 bg-gray-200 rounded col-span-2"></div>
													<div class="h-2 bg-gray-200 rounded col-span-1"></div>
												</div>
												<div class="h-2 bg-gray-200 rounded"></div>
											</div>
										</div>
									</div>
								</div>`;
                let html = '';
                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(item => {
                            let url = `<?php echo e(route('food.detail', ':id')); ?>`.replace(
                                ':id', item.id);
                            html += `
                            <div class="border border-blue-300 hover:bg-blue-500 hover:text-white shadow rounded-md p-4 max-w-sm w-full mx-auto mb-3">
                                <div class="flex space-x-4">
                                    <div class="flex-1 space-y-6 py-1">
                                        ${item.schedule.name} - ${item.name}
                                        <div class="space-y-3">
                                            <div class="grid grid-cols-3 gap-4 text-sm">
                                                <span>Calorie : ${item.calories}gr</span>
                                                <span>Carbo : ${item.carbo}gr</span>
                                                <span>Fat : ${item.fat}gr</span>
                                            </div>
                                            <div class="grid grid-cols-3 gap-4">
                                                Rp.${item.price}
                                            </div>
                                            <div class="flex justify-end">
                                                <a href="${url}" class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-blue-600 mr-2">Detail</a>
                                            <?php if(auth()->guard()->check()): ?>
                                                <?php if(Auth::user()->role == 'user'): ?>
                                                    <form onSubmit="addFood(event)" action="<?php echo e(route('food.add')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="food_id" value="${item.id}">
                                                        <button type="submit"
                                                            class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-blue-600 mr-2">Buy</button>
                                                    </form>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            `;
                        });
                    }).then(() => {
                        modalBody.innerHTML = html;
                        modal.classList.remove('hidden');
                    });
            });
        });

        document.getElementById('cart-modal').addEventListener('click', () => {
            const url = `<?php echo e(route('cart.get')); ?>`;
            const modalBody = document.querySelector('#cart-body');
            modalBody.innerHTML = `
                <div class="border border-blue-300 shadow rounded-md p-4 max-w-sm w-full mx-auto">
									<div class="animate-pulse flex space-x-4">
										<div class="rounded-full bg-gray-200 h-10 w-10"></div>
										<div class="flex-1 space-y-6 py-1">
											<div class="h-2 bg-gray-200 rounded"></div>
											<div class="space-y-3">
												<div class="grid grid-cols-3 gap-4">
													<div class="h-2 bg-gray-200 rounded col-span-2"></div>
													<div class="h-2 bg-gray-200 rounded col-span-1"></div>
												</div>
												<div class="h-2 bg-gray-200 rounded"></div>
											</div>
										</div>
									</div>
								</div>`;
            let html = '';
            let total = 0;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    data.forEach(item => {
                        total += parseInt(item.food.price);
                        let url = `<?php echo e(route('cart.delete', ':id')); ?>`.replace(':id', item
                            .id);
                        html += `
                            <div class="border border-blue-300 hover:bg-blue-500 hover:text-white shadow rounded-md p-4 max-w-sm w-full mx-auto mb-3">
                                <div class="flex justify-between">
                                    <div class="flex py-1">
                                        ${item.food.name} - Rp.${item.food.price}
                                    </div>
                                    <div class="flex py-1">
                                        <form onSubmit="removeFood(event)" action="${url}" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white text-red-500 mr-2">
                                                <i class="bi bi-trash"></i>
                                                </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            `;
                    });
                })
                .then(() => {
                    if (total > 0) {
                        html += `
                        <div class="border border-blue-300 hover:bg-blue-500 hover:text-white shadow rounded-md p-4 max-w-sm w-full mx-auto mb-3">
                            <div class="flex justify-between">
                                <div class="flex py-1">
                                    Total
                                </div>
                                <div class="flex py-1">
                                    Rp.${total}
                                </div>
                            </div>
                        </div>
                        <div class="border border-blue-300 hover:bg-blue-500 hover:text-white shadow rounded-md p-4 max-w-sm w-full mx-auto mb-3">
                            <div class="flex justify-between">
                                <div class="flex py-1">
                                    Checkout
                                </div>
                                <div class="flex py-1">
                                    <form onSubmit="checkout(event)" action="<?php echo e(route('cart.checkout')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="price" value="${total}">
                                        <button type="submit"
                                            class="inline-block font-normal text-center px-3 py-2 leading-normal text-base rounded cursor-pointer text-white bg-blue-500 hover:bg-blue-600 mr-2">
                                            Checkout
                                            </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    `;
                    }
                    modalBody.innerHTML = html;
                    modal.classList.remove('hidden');
                });
        });

        closeButtons.forEach(button => {
            button.addEventListener('click', () => {
                modal.classList.add('hidden');
            });
        });
    });
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })

    const addFood = async (event) => {
        event.preventDefault();
        const form = event.target;
        const url = form.getAttribute('action');
        const method = form.getAttribute('method');
        const data = new FormData(form);
        const response = await fetch(url, {
            method: method,
            body: data
        });
        const dataResponse = await response.json();
        if (dataResponse.status === 'success') {
            Toast.fire({
                icon: 'success',
                title: `${dataResponse.message}`
            })
        } else {
            Toast.fire({
                icon: 'error',
                title: `${dataResponse.message}`
            })
        }

        document.querySelector('#closeModal').click();
    }

    const removeFood = async (event) => {
        event.preventDefault();
        const form = event.target;
        const url = form.getAttribute('action');
        const method = form.getAttribute('method');
        const data = new FormData(form);
        const response = await fetch(url, {
            method: method,
            body: data
        });
        const dataResponse = await response.json();
        if (dataResponse.status === 'success') {
            Toast.fire({
                icon: 'success',
                title: `${dataResponse.message}`
            })
        } else {
            Toast.fire({
                icon: 'error',
                title: `${dataResponse.message}`
            })
        }
        document.getElementById('cart-modal').click();
    }

    const checkout = async (event) => {
        event.preventDefault();
        const form = event.target;
        const url = form.getAttribute('action');
        const method = form.getAttribute('method');
        const data = new FormData(form);
        const response = await fetch(url, {
            method: method,
            body: data
        });
        const dataResponse = await response.json();
        if (dataResponse.status === 'success') {
            Toast.fire({
                icon: 'success',
                title: `${dataResponse.message}`
            })
        } else {
            Toast.fire({
                icon: 'error',
                title: `${dataResponse.message}`
            })
        }
        document.getElementById('cart-modal').click();
    }
</script>
<?php /**PATH E:\COLLEGE\Semester 5\OOAD\mobile-apps-for-healthy-life\mobile-apps-for-healthy-life\resources\views/dashboard.blade.php ENDPATH**/ ?>