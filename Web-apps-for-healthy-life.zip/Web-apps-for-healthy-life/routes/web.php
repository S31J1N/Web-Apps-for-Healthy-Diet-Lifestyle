<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::middleware('auth')->group(function () {
    Route::post('/comment', [DashboardController::class, 'addComment'])->name('comment.store');
    Route::post('/comment/reply/{comment}', [DashboardController::class, 'addReply'])->name('comment.reply');
    Route::delete('cart/{transactionDetail}', [DashboardController::class, 'deleteCart'])->name('cart.delete');
    Route::put('cart', [DashboardController::class, 'checkout'])->name('cart.checkout');
    Route::get('/transaction', [DashboardController::class, 'getTransaction'])->name('transaction.get');
    Route::get('/transaction/{transaction}', [DashboardController::class, 'getTransactionDetail'])->name('transaction.detail');
    Route::get('chat', function () {
        return view('chat');
    })->name('chat');
    Route::get('/getChat', [DashboardController::class, 'getChat'])->name('chat.get');
    Route::post('/sendChat', [DashboardController::class, 'sendChat'])->name('chat.send');
    Route::get('/cart', [DashboardController::class, 'getCart'])->name('cart.get');
    Route::get('/profile', [DashboardController::class, 'getProfile'])->name('profile');
    Route::get('/update-profile', function () {
        return view('profile');
    })->name('profile.get');
    Route::post('/update-profile', [DashboardController::class, 'updateProfile'])->name('profile.update');
    Route::middleware('admin')->group(function () {
        Route::get('/admin/all-user', [DashboardController::class, 'getAllUser'])->name('user.get');
        Route::get('/admin/chat/{user}', [DashboardController::class, 'getChatUser'])->name('chat.user');
        Route::get('/admin/chat/{user}/getChat', [DashboardController::class, 'getChatUserById'])->name('chat.user.get');
        Route::post('/admin/sendChatUser/{user}', [DashboardController::class, 'sendChatUser'])->name('chat.sendUser');
        Route::get('/admin/category', [AdminController::class, 'category'])->name('category.index');
        Route::get('/admin/category/get', [AdminController::class, 'getCategory'])->name('category.get');
        Route::get('/admin/category/{category}', [AdminController::class, 'getCategoryById'])->name('category.detail');
        Route::post('/admin/category', [AdminController::class, 'addCategory'])->name('category.store');
        Route::put('/admin/category/{category}', [AdminController::class, 'updateCategory'])->name('category.update');
        Route::delete('/admin/category/{category}', [AdminController::class, 'deleteCategory'])->name('category.delete');
        Route::get('/admin/food', [AdminController::class, 'food'])->name('food.index');
        Route::get('/admin/food/get', [AdminController::class, 'getFood'])->name('food.get');
        Route::get('/admin/food/{food}', [AdminController::class, 'getFoodById'])->name('food.detail.get');
        Route::post('/admin/food', [AdminController::class, 'addFood'])->name('food.store');
        Route::put('/admin/food/{food}', [AdminController::class, 'updateFood'])->name('food.update');
        Route::delete('/admin/food/{food}', [AdminController::class, 'deleteFood'])->name('food.delete');
        Route::get('/admin/schedule/get', [AdminController::class, 'getSchedule'])->name('schedule.get');
    });
});
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
Route::post('/food', [DashboardController::class, 'addFood'])->name('food.add');
Route::get('/food/{food}', [DashboardController::class, 'foodDetail'])->name('food.detail');

require __DIR__.'/auth.php';
