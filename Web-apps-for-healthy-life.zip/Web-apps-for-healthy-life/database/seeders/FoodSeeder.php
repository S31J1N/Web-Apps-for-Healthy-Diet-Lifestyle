<?php

namespace Database\Seeders;

use App\Models\Food;
use Illuminate\Database\Seeder;

class FoodSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $foods = [
            [
                'name' => 'Miso Soup',
                'calories' => '27',
                'carbo' => '11.3',
                'fat' => '0.1',
                'category_id' => 1,
                'schedule_id' => 1,
                'price' => '18000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Mie Shirataki',
                'calories' => '20',
                'carbo' => '4',
                'fat' => '0',
                'category_id' => 1,
                'schedule_id' => 2,
                'price' => '21000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Nasi Konnyaku',
                'calories' => '37',
                'carbo' => '18.3',
                'fat' => '0.3',
                'category_id' => 1,
                'schedule_id' => 3,
                'price' => '15000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Gado-gado',
                'calories' => '20',
                'carbo' => '15',
                'fat' => '0.4',
                'category_id' => 2,
                'schedule_id' => 1,
                'price' => '13000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Nasi Merah Ikan Woku',
                'calories' => '40',
                'carbo' => '23',
                'fat' => '1.2',
                'category_id' => 2,
                'schedule_id' => 2,
                'price' => '23000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Dada Ayam Sambal Hijau',
                'calories' => '29',
                'carbo' => '8',
                'fat' => '0.6',
                'category_id' => 2,
                'schedule_id' => 3,
                'price' => '18000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Mashed Potato With Egg Yolks',
                'calories' => '20',
                'carbo' => '13',
                'fat' => '0.2',
                'category_id' => 3,
                'schedule_id' => 1,
                'price' => '25000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Fish and Potato Wedges',
                'calories' => '24',
                'carbo' => '14',
                'fat' => '0.8',
                'category_id' => 3,
                'schedule_id' => 2,
                'price' => '35000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Lemon Chicken',
                'calories' => '18',
                'carbo' => '8',
                'fat' => '0.3',
                'category_id' => 3,
                'schedule_id' => 3,
                'price' => '20000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];
        Food::insert($foods);
    }
}
